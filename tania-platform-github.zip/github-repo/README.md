# منصة تانيا — Tania Supply Platform

منصة عربية RTL لإدارة مهام الإمداد والمستودعات، مبنية كتطبيق ويب أحادي الملف.

## 🚀 النشر على Cloudflare Pages

1. ارفع هذا المستودع على GitHub
2. في [Cloudflare Pages](https://pages.cloudflare.com):
   - اضغط **Create a project** ← **Connect to Git**
   - اختر المستودع
   - **Build settings:**
     - Framework preset: `None`
     - Build command: *(اتركه فارغاً)*
     - Build output directory: `/` (الجذر)
   - اضغط **Save and Deploy**

## ⚙️ الإعداد بعد النشر

1. افتح رابط Cloudflare Pages
2. ادخل بحساب الأدمن
3. لوحة الأدمن ← **النسخ والاستعادة** ← قسم Firebase
4. أدخل `apiKey` و `authDomain` و `projectId` ← **حفظ وتوصيل**

## 📁 هيكل الملفات

```
├── index.html      ← المنصة الكاملة
├── _headers        ← رؤوس أمان Cloudflare
├── _redirects      ← توجيه المسارات
├── robots.txt      ← منع الفهرسة
└── README.md       ← هذا الملف
```

## 🔧 التقنيات

- **Frontend:** HTML + CSS + JavaScript (vanilla)
- **Database:** Firebase Firestore
- **Charts:** ApexCharts 3.45.2
- **Email:** EmailJS
- **Hosting:** Cloudflare Pages
